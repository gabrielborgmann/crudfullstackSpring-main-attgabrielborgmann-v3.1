package com.exemplo.crudmongo.repository;

import com.exemplo.crudmongo.model.Pessoa;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface PessoaRepository extends MongoRepository<Pessoa, String> {

    List<Pessoa> findByNome(String nome);
    List<Pessoa> findByIdade(int idade);
    List<Pessoa> findByMatricula(String matricula);
    List<Pessoa> findBySexo(String sexo);
}
