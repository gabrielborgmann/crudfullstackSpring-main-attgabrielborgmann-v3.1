package com.exemplo.crudmongo.repository;

import com.exemplo.crudmongo.model.Curso;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CursoRepository extends MongoRepository<Curso, String> {
}