package com.exemplo.crudmongo.controller;

import com.exemplo.crudmongo.model.Curso;
import com.exemplo.crudmongo.service.CursoService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cursos")
@CrossOrigin(origins = "*")
public class CursoController {

    private final CursoService service;

    public CursoController(CursoService service) {
        this.service = service;
    }

    // ROLE_ALUNO e ROLE_COORDENADOR podem listar todos
    @GetMapping
    @PreAuthorize("hasAnyRole('ALUNO', 'COORDENADOR')")
    public List<Curso> listar() {
        return service.listarTodos();
    }

    // ROLE_ALUNO e ROLE_COORDENADOR podem buscar um por ID
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ALUNO', 'COORDENADOR')")
    public Curso buscarPorId(@PathVariable String id) {
        return service.buscarPorId(id);
    }

    // Apenas ROLE_COORDENADOR pode criar
    @PostMapping
    @PreAuthorize("hasRole('COORDENADOR')")
    public Curso criar(@Valid @RequestBody Curso curso) {
        return service.salvar(curso);
    }

    // Apenas ROLE_COORDENADOR pode atualizar
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('COORDENADOR')")
    public Curso atualizar(@PathVariable String id, @Valid @RequestBody Curso curso) {
        return service.atualizar(id, curso);
    }

    // Apenas ROLE_COORDENADOR pode excluir
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('COORDENADOR')")
    public void excluir(@PathVariable String id) {
        service.excluir(id);
    }
}