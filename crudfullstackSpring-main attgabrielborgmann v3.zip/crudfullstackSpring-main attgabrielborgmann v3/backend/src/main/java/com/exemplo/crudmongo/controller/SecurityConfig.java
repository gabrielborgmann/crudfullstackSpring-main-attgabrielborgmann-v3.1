package com.exemplo.crudmongo.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity(prePostEnabled = true) // habilita @PreAuthorize
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Para APIs REST, geralmente desabilitamos CSRF
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                // Libera Swagger
                .requestMatchers(
                    "/v3/api-docs/**",
                    "/swagger-ui/**",
                    "/swagger-ui.html"
                ).permitAll()
                // Qualquer outra requisição precisa estar autenticada.
                .anyRequest().authenticated()
            )
            // Autenticação básica para testes rápidos (Authorization: Basic ...)
            .httpBasic(Customizer.withDefaults());

        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder encoder) {
        // Usuário com papel ALUNO
        var aluno = User.withUsername("aluno")
                .password(encoder.encode("123456"))
                .roles("ALUNO") // vira ROLE_ALUNO
                .build();

        // Usuário com papel COORDENADOR (e opcionalmente ALUNO também)
        var coordenador = User.withUsername("coord")
                .password(encoder.encode("123456"))
                .roles("COORDENADOR") // vira ROLE_COORDENADOR
                .build();

        return new InMemoryUserDetailsManager(aluno, coordenador);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}