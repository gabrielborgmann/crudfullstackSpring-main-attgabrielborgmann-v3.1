package com.exemplo.crudmongo.service;

import com.exemplo.crudmongo.model.Pessoa;
import com.exemplo.crudmongo.repository.PessoaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PessoaService {

    private final PessoaRepository repository;

    public PessoaService(PessoaRepository repository) {
        this.repository = repository;
    }

    public List<Pessoa> listarTodas() {
        return repository.findAll();
    }

    public Pessoa salvar(Pessoa pessoa) {
        return repository.save(pessoa);
    }

    public Pessoa atualizar(String id, Pessoa novaPessoa) {
        Pessoa pessoa = repository.findById(id).orElseThrow();
        pessoa.setNome(novaPessoa.getNome());
        pessoa.setIdade(novaPessoa.getIdade());
        pessoa.setMatricula(novaPessoa.getMatricula());
        pessoa.setSexo(novaPessoa.getSexo());
        return repository.save(pessoa);
    }

    public void excluir(String id) {
        repository.deleteById(id);
    }

    public List<Pessoa> buscarPorFiltros(String nome, Integer idade, String matricula, String sexo) {
        if (nome == null && idade == null && matricula == null && sexo == null) {
            return repository.findAll();
        }
        if (nome != null) return repository.findByNome(nome);
        if (idade != null) return repository.findByIdade(idade);
        if (matricula != null) return repository.findByMatricula(matricula);
        if (sexo != null) return repository.findBySexo(sexo);
        return List.of();
    }
}