package com.exemplo.crudmongo.service;

import com.exemplo.crudmongo.model.Curso;
import com.exemplo.crudmongo.repository.CursoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CursoService {

    private final CursoRepository repository;

    public CursoService(CursoRepository repository) {
        this.repository = repository;
    }

    public List<Curso> listarTodos() {
        return repository.findAll();
    }

    public Curso salvar(Curso curso) {
        return repository.save(curso);
    }

    public Curso atualizar(String id, Curso novoCurso) {
        Curso curso = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Curso não encontrado com ID: " + id));

        curso.setNome(novoCurso.getNome());
        curso.setCargaHoraria(novoCurso.getCargaHoraria());
        curso.setAtivo(novoCurso.isAtivo());

        return repository.save(curso);
    }

    public void excluir(String id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Curso não encontrado com ID: " + id);
        }
        repository.deleteById(id);
    }

    public Curso buscarPorId(String id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Curso não encontrado com ID: " + id));
    }
}