package com.exemplo.crudmongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.NotBlank;

@Document(collection = "cursos")
public class Curso {

    @Id
    private String id;

    @NotBlank
    private String nome;

    private String descricao;

    public Curso() {
    }

    public Curso(String id, String nome, String descricao) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
    }

    // getters/setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Object getCargaHoraria() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getCargaHoraria'");
    }

    public void setCargaHoraria(Object cargaHoraria) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setCargaHoraria'");
    }

    public Object isAtivo() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isAtivo'");
    }

    public void setAtivo(Object ativo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setAtivo'");
    }
}