package com.exemplo.crudmongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudMongoApplication {
    public static void main(String[] args) {
        SpringApplication.run(CrudMongoApplication.class, args);
    }
}
